# 建议补充到 translation_utils.py 的 EVENT_TYPE_MAP：
EVENT_TYPE_MAP.update({
    "Card": "请填写中文",
    "Goal": "请填写中文",
    "Var": "请填写中文",
    "subst": "请填写中文",
})

# 建议补充到 translation_utils.py 的 REFEREE_MAP：
REFEREE_MAP.update({
    "Alejandro Hernandez, Spain": "请填写中文",
    "Chris Kavanagh, England": "请填写中文",
    "César Soto Grado, Spain": "请填写中文",
    "Daniel Siebert, Germany": "请填写中文",
    "Gael Angoula, France": "请填写中文",
    "Kevin Bonacina, Italy": "请填写中文",
    "Matthias Jollenbeck, Germany": "请填写中文",
    "Ricardo De Burgos Bengoetxea, Spain": "请填写中文",
    "Sami Ahmed Al-Jurays, Saudi Arabia": "请填写中文",
    "Serdar Gozubuyuk, Netherlands": "请填写中文",
    "Sven Jablonski, Germany": "请填写中文",
})

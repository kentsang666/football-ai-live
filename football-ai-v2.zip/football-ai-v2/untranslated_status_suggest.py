# 建议补充到 translation_utils.py 的 STATUS_MAP：
STATUS_MAP.update({
})

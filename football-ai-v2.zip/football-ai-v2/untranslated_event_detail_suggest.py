# 建议补充到 translation_utils.py 的 EVENT_DETAIL_MAP：
EVENT_DETAIL_MAP.update({
    "Goal Disallowed": "请填写中文",
    "Goal Disallowed - Foul": "请填写中文",
    "Goal Under Review - offside": "请填写中文",
    "Missed Penalty": "请填写中文",
    "Normal Goal": "请填写中文",
    "Own Goal": "请填写中文",
    "Penalty": "请填写中文",
    "Red Card": "请填写中文",
    "Substitution 1": "请填写中文",
    "Substitution 2": "请填写中文",
    "Substitution 3": "请填写中文",
    "Substitution 4": "请填写中文",
    "Substitution 5": "请填写中文",
    "Yellow Card": "请填写中文",
})

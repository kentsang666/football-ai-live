# 建议补充到 translation_utils.py 的 LEAGUE_MAP：
LEAGUE_MAP.update({
    "Premier League": "请填写正确中文",
})


import requests
import datetime
from translation_utils import LEAGUE_WHITELIST

API_KEY = "8056557685c490a60424687d4a529367" # I need to find the API KEY from main.py, I will guess/search it or use env
API_URL = "https://v3.football.api-sports.io/fixtures"

# I will try to read the API KEY from main.py first. It is likely hardcoded.
# Searching main.py for API_KEY
